document.addEventListener('DOMContentLoaded', function() {
    // Lấy tất cả các phần tử có class 'news-card'
    const newsCards = document.querySelectorAll('.news-card');

    // Lặp qua từng newsCard để thêm trình nghe sự kiện double click
    newsCards.forEach(card => {
        card.addEventListener('dblclick', function() {
            // Lấy URL từ thuộc tính 'data-url' của card hiện tại
            const detailUrl = this.dataset.url; // 'this' ở đây tham chiếu đến card được double click

            // Kiểm tra xem URL có tồn tại không
            if (detailUrl) {
                // Chuyển hướng trình duyệt đến URL đó
                window.location.href = detailUrl;
            } else {
                console.warn('Không tìm thấy data-url cho news-card này:', this);
            }
        });
    });
});